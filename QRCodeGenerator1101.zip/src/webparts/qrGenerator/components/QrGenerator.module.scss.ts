/* tslint:disable */
require("./QrGenerator.module.css");
const styles = {
  qrGenerator: 'qrGenerator_6c63b381',
  teams: 'teams_6c63b381',
  welcome: 'welcome_6c63b381',
  container: 'container_6c63b381',
  controls: 'controls_6c63b381',
  result: 'result_6c63b381',
  title: 'title_6c63b381',
  shortUrl: 'shortUrl_6c63b381',
  buttons: 'buttons_6c63b381',
  defaultButton: 'defaultButton_6c63b381',
  links: 'links_6c63b381'
};

export default styles;
/* tslint:enable */