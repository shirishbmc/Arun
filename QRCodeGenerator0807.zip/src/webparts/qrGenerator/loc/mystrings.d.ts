declare interface IQrGeneratorWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  TitleFieldLabel: string;
  AppLocalEnvironmentSharePoint: string;
  AppLocalEnvironmentTeams: string;
  AppSharePointEnvironment: string;
  AppTeamsTabEnvironment: string;
}

declare module 'QrGeneratorWebPartStrings' {
  const strings: IQrGeneratorWebPartStrings;
  export = strings;
}
