import { HttpClient, IHttpClientOptions, HttpClientResponse }                                     from '@microsoft/sp-http';
import { QRGeneratorConstants }                                                                   from '../common/constants';

export class BitlyService{
    private httpClient:HttpClient;
    constructor(httpClient:HttpClient){
        this.httpClient = httpClient;
    }

    public createShortLink = (longUrl: string, guid: any, title: string):Promise<any> => {
        return new Promise<any>((resolve, reject) => {
            var shortLinkRequest = {
                "long_url": longUrl,
                "domain": QRGeneratorConstants.Domain,
                "group_guid": guid,
                "title": title,
            } 
            
            let headers:IHttpClientOptions = {
                method: 'POST',
                headers:{
                    'Authorization': 'Bearer '+ QRGeneratorConstants.userToken +'',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(shortLinkRequest)        
            }
            this.httpClient.fetch('https://api-ssl.bitly.com/v4/bitlinks', HttpClient.configurations.v1, headers ).then((response: HttpClientResponse) => {  
                return response.json();  
            })  
            .then(shortenLinkResponse => { 
                resolve(shortenLinkResponse)
            });
        });        
    }

    public createQRCode = (bitLink:string, colorCode:string, guid:any, title: string):Promise<any> => {
        return new Promise<any>((resolve, reject) => {
            let qrRequest = {
                color: colorCode, 
                exclude_bitly_logo: true,
                image_format: "png",         
                logo_image_guid: guid,
                title: title,                     
            }
        
            let headers:IHttpClientOptions = {
                method: 'POST',
                headers:{
                  'Authorization': 'Bearer '+ QRGeneratorConstants.userToken +'',
                  'Content-Type': 'application/json'
                },
                body: JSON.stringify(qrRequest)        
            } 
            this.httpClient.fetch('https://api-ssl.bitly.com/v4/bitlinks/'+ bitLink +'/qr', HttpClient.configurations.v1, headers ).then((response: HttpClientResponse) => {  
                return response.json();  
            })  
            .then(jsonResponse => { 
                resolve(jsonResponse);
            }); 
        });
    }

    public updateQRCode = (bitLink: string,colorCode:string, guid:any,):Promise<any> =>{
        return new Promise<any>((resolve, reject) => {
            let qrRequest = {
                color: colorCode, 
                exclude_bitly_logo: true,
                image_format: "png",         
                logo_image_guid: guid                     
              }
        
            let headers:IHttpClientOptions = {
                method: 'PATCH',
                headers:{
                  'Authorization': 'Bearer '+ QRGeneratorConstants.userToken +'',
                  'Content-Type': 'application/json'
                },
                body: JSON.stringify(qrRequest)        
            }
            this.httpClient.fetch('https://api-ssl.bitly.com/v4/bitlinks/'+ bitLink +'/qr', HttpClient.configurations.v1, headers ).then((response: HttpClientResponse) => {  
                return response.json();  
            })  
            .then(jsonResponse => { 
                resolve(jsonResponse);
            });
        });
    }

    public retrieveQRCode = (bitLink: string):Promise<any> => {
        return new Promise<any>((resolve, reject) => {
            let headers:IHttpClientOptions = {
                method: 'GET',
                headers:{
                  'Authorization': 'Bearer '+ QRGeneratorConstants.userToken +'',                  
                },                
              }     
              this.httpClient.fetch('https://api-ssl.bitly.com/v4/bitlinks/'+ bitLink +'/qr?image_format=svg', HttpClient.configurations.v1, headers ).then((response: HttpClientResponse) => {  
                return response.json();  
              })  
              .then(jsonResponse => { 
                resolve(jsonResponse);
              });
        });
    }
}