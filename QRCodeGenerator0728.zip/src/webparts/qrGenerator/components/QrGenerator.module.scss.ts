/* tslint:disable */
require("./QrGenerator.module.css");
const styles = {
  qrGenerator: 'qrGenerator_eadd2fc7',
  teams: 'teams_eadd2fc7',
  welcome: 'welcome_eadd2fc7',
  container: 'container_eadd2fc7',
  controls: 'controls_eadd2fc7',
  result: 'result_eadd2fc7',
  title: 'title_eadd2fc7',
  shortUrl: 'shortUrl_eadd2fc7',
  buttons: 'buttons_eadd2fc7',
  defaultButton: 'defaultButton_eadd2fc7',
  links: 'links_eadd2fc7'
};

export default styles;
/* tslint:enable */