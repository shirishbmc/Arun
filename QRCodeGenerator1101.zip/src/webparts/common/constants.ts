import { IDropdownOption }                                                                        from '@fluentui/react/lib/components/Dropdown';
import { IChoiceGroupOption }                                                                     from '@fluentui/react/lib/components/ChoiceGroup';

export class QRGeneratorConstants{
    public static readonly userToken = 'c5e59588362ef7521a5624942ef705280c171bc7';
    public static readonly Domain = 'fidlink.info';
    public static readonly options:IDropdownOption[] = [
        { key: 'B0110j6JDxR', text: 'Self service' },
        { key: 'B011092YQki', text: 'Splash Events' },  
        { key: 'B0110GsoBz4', text: 'Seismic' },  
        { key: 'B0110AJQkNQ', text: 'WI Talent' },
      ];      
    public static readonly colorOptions: IChoiceGroupOption[] = [
        { key: '000000', text: 'Black', title:'Black' },
        { key: '000001', text: 'Black with icon', title: 'Black with icon',  }, // keeping a dummy key as color code is same, this is to avoid default radio button selection
        { key: '368727', text: 'Green', title: 'Green' },  
        { key: '368722', text: 'Green with icon', title: 'Green with icon' } // keeping a dummy key as color code is same, this is to avoid default radio button selection
      ];
    public static readonly blackGUID = "In7rbMNTmNI";
    public static readonly greenGUID = "In7rcsRTZhs";
    public static readonly httpError = "Please use HTTPS for the URL.";
    public static readonly defaultSelectedOptionGUID = "B0110j6JDxR";
    public static readonly defaultSelectedColorCode = "000000";
    public static readonly dropDownLabel = "Select an option:";
    public static readonly colorLabel = "Color:";
    public static readonly BLACK = "Black";
    public static readonly BLACKWITHICON = "Black with icon";
    public static readonly GREEN = "Green";
    public static readonly GREENWITHICON = "Green with icon";
}