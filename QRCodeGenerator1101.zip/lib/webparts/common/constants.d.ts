import { IDropdownOption } from '@fluentui/react/lib/components/Dropdown';
import { IChoiceGroupOption } from '@fluentui/react/lib/components/ChoiceGroup';
export declare class QRGeneratorConstants {
    static readonly userToken = "c5e59588362ef7521a5624942ef705280c171bc7";
    static readonly Domain = "fidlink.info";
    static readonly options: IDropdownOption[];
    static readonly colorOptions: IChoiceGroupOption[];
    static readonly blackGUID = "In7rbMNTmNI";
    static readonly greenGUID = "In7rcsRTZhs";
    static readonly httpError = "Please use HTTPS for the URL.";
    static readonly defaultSelectedOptionGUID = "B0110j6JDxR";
    static readonly defaultSelectedColorCode = "000000";
    static readonly dropDownLabel = "Select an option:";
    static readonly colorLabel = "Color:";
    static readonly BLACK = "Black";
    static readonly BLACKWITHICON = "Black with icon";
    static readonly GREEN = "Green";
    static readonly GREENWITHICON = "Green with icon";
}
//# sourceMappingURL=constants.d.ts.map