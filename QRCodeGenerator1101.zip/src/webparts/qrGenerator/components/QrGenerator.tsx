import * as React                                                                                 from 'react';
import styles                                                                                     from './QrGenerator.module.scss';
import { IQrGeneratorProps }                                                                      from './IQrGeneratorProps';
import { Dropdown }                                                                               from '@fluentui/react/lib/components/Dropdown';
import { TextField }                                                                              from '@fluentui/react/lib/components/TextField';
import { PrimaryButton, DefaultButton }                                                           from '@fluentui/react/lib/components/Button';
import { Label }                                                                                  from '@fluentui/react/lib/components/Label';
import { VerticalDivider }                                                                        from '@fluentui/react/lib/components/Divider';
import { Image }                                                                                  from '@fluentui/react/lib/components/Image';
import { ChoiceGroup}                                                                             from '@fluentui/react/lib/components/ChoiceGroup';
import { MessageBar,
MessageBarType }                                                                                  from '@fluentui/react/lib/MessageBar';
import { QRGeneratorConstants }                                                                   from '../../common/constants';
import { BitlyService }                                                                           from '../../common/service';
import * as strings                                                                               from 'QrGeneratorWebPartStrings';

export interface IQrGeneratorState{
  longUrl: string;
  shortenUrl: string;
  selectedGuid: string | number;
  qrCode: any;
  selectedColor: string | number;
  selectedLogoGUID: any;
  showError: boolean;
  errorMessage: string;
}

export default class QrGenerator extends React.Component<IQrGeneratorProps, IQrGeneratorState> {  
  private _colorCode = QRGeneratorConstants.defaultSelectedColorCode;
  private bitlyService:BitlyService;

  constructor(props:IQrGeneratorProps, state:IQrGeneratorState){
    super(props);  
    this.bitlyService = new BitlyService(this.props.httpClient);
    this.state = {
      longUrl: '',
      shortenUrl: '',
      selectedGuid: QRGeneratorConstants.defaultSelectedOptionGUID,
      qrCode: null,
      selectedColor: QRGeneratorConstants.defaultSelectedColorCode,
      selectedLogoGUID: "",
      showError: false,
      errorMessage: ""
    }         
  }  
  public render(): React.ReactElement<IQrGeneratorProps> {    
    return (
      <section className={`${styles.qrGenerator}`}>
        <div className={styles.title}>
          {this.props.title}
        </div> 
        <div className={styles.container}>
          <div className={styles.controls}>
            <TextField label='URL:' value={this.state.longUrl} onChange={(ev, val)=> this.setState({ longUrl: val})} />
            <Dropdown
              label = { QRGeneratorConstants.dropDownLabel }
              options = { QRGeneratorConstants.options }
              onChange = {(ev, option, index)=>{this.setState({ selectedGuid: option.key })}}
            />
            <ChoiceGroup 
              label = { QRGeneratorConstants.colorLabel }
              options = {QRGeneratorConstants.colorOptions}            
              selectedKey = { this.state.selectedColor }
              onChange={(ev,option) => {
                if(option.title === QRGeneratorConstants.BLACK ){
                  // set black guid
                  this._colorCode = option.key;
                  this.setState({
                    selectedColor: option.key,
                    selectedLogoGUID: ""
                  },()=> {this.updateQRCode(); })
                }
                if(option.title === QRGeneratorConstants.BLACKWITHICON ){
                  // set black guid
                  this._colorCode = QRGeneratorConstants.defaultSelectedColorCode;
                  this.setState({
                    selectedColor: option.key,
                    selectedLogoGUID: QRGeneratorConstants.blackGUID
                  },()=> {this.updateQRCode(); })
                }
                if(option.title === QRGeneratorConstants.GREEN ){
                  // set green guid
                  this._colorCode = option.key;
                  this.setState({
                    selectedColor: option.key,
                    selectedLogoGUID: ""
                  },()=> {this.updateQRCode(); })
                } 
                if(option.title === QRGeneratorConstants.GREENWITHICON ){
                  // set green guid
                  this._colorCode = '368727';
                  this.setState({
                    selectedColor: option.key,
                    selectedLogoGUID: QRGeneratorConstants.greenGUID
                  },()=> {this.updateQRCode(); })
                }           
              }}
            />            
            <div className={styles.buttons}>
              <PrimaryButton text= { strings.GenerateButtonLabel } onClick={this.generateShortLink} />
              <DefaultButton text= { strings.ClearButtonLabel }  className={styles.defaultButton} onClick={()=> 
                this.setState({ longUrl:'', shortenUrl: '', qrCode: null, selectedColor: QRGeneratorConstants.defaultSelectedColorCode,
                selectedLogoGUID: QRGeneratorConstants.blackGUID })} 
              />
            </div>
          </div>
          <VerticalDivider />
          <div className={styles.result}>
            <div style={{ display:'flex' }}>
              <Label>Shorten URL:</Label>
              <Label className={styles.shortUrl}>{this.state.shortenUrl}</Label>
            </div>            
            <div>
            <Label>QR Code:</Label>
            <Image src={this.state.qrCode} style={{ height:'200px' }} />
            </div>
          </div>          
        </div>  
        {
            this.state.showError && 
            <MessageBar
              messageBarType={MessageBarType.error}
              isMultiline={false}
              onDismiss={() => this.setState({ showError: false, errorMessage: '' })} // Add a handler to dismiss the error message
            >
              {this.state.errorMessage}
            </MessageBar>
        }             
      </section>
    );
  }

  private validateInputs = ():boolean => {
    let isValidationSuccess = true;

    if (this.state.longUrl.toString().toLowerCase().startsWith('http://')) {
        isValidationSuccess = false;
        this.setState({
          showError : true,
          errorMessage: QRGeneratorConstants.httpError
        })
    }
    return isValidationSuccess;
  }

  private generateShortLink = async() => {   
    if(this.validateInputs()){
        // generate Short Link  
        var title = "Shirish" //this.props.ctx.pageContext.user.displayName;
        this.bitlyService.createShortLink(this.state.longUrl, this.state.selectedGuid, title).then( response => {
          console.log(response);
          this.setState({
            shortenUrl: response.link // store the short link in state
          },()=>{ // trigger QR code generation call [ QR code generation can be triggered only after short link is generated ]
            let bitLink = this.state.shortenUrl.replace(/(^\w+:|^)\/\//, '');
            this.bitlyService.createQRCode(bitLink, this._colorCode, this.state.selectedLogoGUID, title).then( qrResponse => {
              console.log(qrResponse);  
              if(qrResponse.errors && qrResponse.errors[0] != undefined){ // if QR already exists, trigger retrieve QR function
                console.log("QR already exists.");
                this.retriveQRCode(bitLink);
              }
              else{
                this.setState({ // else display the QR
                  qrCode: qrResponse.qr_code
                });
              }                       
            });  
          })
        });
      }  
  }

  private updateQRCode = () => {
    if(this.validateInputs()){
      let link = this.state.shortenUrl.replace(/(^\w+:|^)\/\//, '');
      this.bitlyService.updateQRCode(link, this._colorCode, this.state.selectedLogoGUID).then( response => {
        this.setState({
          qrCode: response.qr_code
        });
      });      
    }    
  }

  private retriveQRCode = (bitLink) => {
    if(this.validateInputs()){
      this.bitlyService.retrieveQRCode(bitLink).then( response => {
        this.setState({
          qrCode: response.qr_code
        });
      })
    }    
  }
}
