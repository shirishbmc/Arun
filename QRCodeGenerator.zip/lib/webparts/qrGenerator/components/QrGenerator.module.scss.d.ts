declare const styles: {
    qrGenerator: string;
    teams: string;
    welcome: string;
    container: string;
    controls: string;
    result: string;
    title: string;
    shortUrl: string;
    buttons: string;
    defaultButton: string;
    links: string;
};
export default styles;
//# sourceMappingURL=QrGenerator.module.scss.d.ts.map