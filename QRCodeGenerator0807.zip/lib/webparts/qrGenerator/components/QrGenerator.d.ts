import * as React from 'react';
import { IQrGeneratorProps } from './IQrGeneratorProps';
export interface IQrGeneratorState {
    longUrl: string;
    shortenUrl: string;
    selectedGuid: string | number;
    qrCode: any;
    selectedColor: string | number;
    selectedLogoGUID: any;
}
export default class QrGenerator extends React.Component<IQrGeneratorProps, IQrGeneratorState> {
    private _colorCode;
    constructor(props: IQrGeneratorProps, state: IQrGeneratorState);
    render(): React.ReactElement<IQrGeneratorProps>;
    private generateShortLink;
    private updateGrCode;
    private retrive;
}
//# sourceMappingURL=QrGenerator.d.ts.map