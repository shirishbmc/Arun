import { HttpClient } from '@microsoft/sp-http';
export declare class BitlyService {
    private httpClient;
    constructor(httpClient: HttpClient);
    createShortLink: (longUrl: string, guid: any, title: string) => Promise<any>;
    createQRCode: (bitLink: string, colorCode: string, guid: any, title: string) => Promise<any>;
    updateQRCode: (bitLink: string, colorCode: string, guid: any) => Promise<any>;
    retrieveQRCode: (bitLink: string) => Promise<any>;
}
//# sourceMappingURL=service.d.ts.map