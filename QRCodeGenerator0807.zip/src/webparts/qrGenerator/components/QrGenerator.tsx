import * as React from 'react';
import styles from './QrGenerator.module.scss';
import { IQrGeneratorProps } from './IQrGeneratorProps';
import { Dropdown, IDropdownOption } from '@fluentui/react/lib/components/Dropdown';
import { TextField } from '@fluentui/react/lib/components/TextField';
import { PrimaryButton, DefaultButton } from '@fluentui/react/lib/components/Button';
import { Label } from '@fluentui/react/lib/components/Label';
import { VerticalDivider } from '@fluentui/react/lib/components/Divider';
import { HttpClient, IHttpClientOptions, HttpClientResponse } from '@microsoft/sp-http';
import { Image } from '@fluentui/react/lib/components/Image';
import { ChoiceGroup, IChoiceGroupOption } from '@fluentui/react/lib/components/ChoiceGroup';

const userToken = 'c5e59588362ef7521a5624942ef705280c171bc7';
const BitlyClient = require('bitly').BitlyClient;
const bitly = new BitlyClient(userToken);

export interface IQrGeneratorState{
  longUrl: string;
  shortenUrl: string;
  selectedGuid: string | number;
  qrCode: any;
  selectedColor: string | number;
  selectedLogoGUID: any;
}

const _options:IDropdownOption[] = [
  { key: 'B0110j6JDxR', text: 'Self service' },
  { key: 'B011092YQki', text: 'Splash Events' },  
  { key: 'B0110GsoBz4', text: 'Seismic' },  
  { key: 'B0110AJQkNQ', text: 'WI Talent' },
]

const colorOptions: IChoiceGroupOption[] = [
  { key: '000000', text: 'Black', title:'Black' },
  { key: '000001', text: 'Black with icon', title: 'Black with icon',  }, // keeping a dummy key as color code is same, this is to avoid default radio button selection
  { key: '368727', text: 'Green', title: 'Green' },  
  { key: '368722', text: 'Green with icon', title: 'Green with icon' } // keeping a dummy key as color code is same, this is to avoid default radio button selection
]
const blackGUID = "In7rbMNTmNI";
const greenGUID = "In7rcsRTZhs";

export default class QrGenerator extends React.Component<IQrGeneratorProps, IQrGeneratorState> {  
  private _colorCode = "000000";
  constructor(props:IQrGeneratorProps, state:IQrGeneratorState){
    super(props);  
    this.state = {
      longUrl: '',
      shortenUrl: '',
      selectedGuid: 'B0110j6JDxR',
      qrCode: null,
      selectedColor: '000000',
      selectedLogoGUID: ""
    }         
  }  
  public render(): React.ReactElement<IQrGeneratorProps> {
    
    return (
      <section className={`${styles.qrGenerator}`}>
        <div className={styles.title}>
          {this.props.title}
        </div> 
        <div className={styles.container}>
          <div className={styles.controls}>
            <TextField label='URL:' value={this.state.longUrl} onChange={(ev, val)=> this.setState({ longUrl: val})} />
            <Dropdown
            label='Select an option:'
            options={_options}
            onChange={(ev, option, index)=>{this.setState({ selectedGuid: option.key })}}
            />
            <ChoiceGroup 
            label='Color:'
            options={colorOptions}            
            selectedKey={this.state.selectedColor}
            onChange={(ev,option) => {
              if(option.title === "Black"){
                // set black guid
                this._colorCode = option.key;
                this.setState({
                  selectedColor: option.key,
                  selectedLogoGUID: ""
                },()=> {this.updateGrCode(); })
              }
              if(option.title === "Black with icon"){
                // set black guid
                this._colorCode = '000000';
                this.setState({
                  selectedColor: option.key,
                  selectedLogoGUID: blackGUID
                },()=> {this.updateGrCode(); })
              }
              if(option.title === "Green"){
                // set green guid
                this._colorCode = option.key;
                this.setState({
                  selectedColor: option.key,
                  selectedLogoGUID: ""
                },()=> {this.updateGrCode(); })
              } 
              if(option.title === "Green with icon"){
                // set green guid
                this._colorCode = '368727';
                this.setState({
                  selectedColor: option.key,
                  selectedLogoGUID: greenGUID
                },()=> {this.updateGrCode(); })
              }           
            }}
            />
            <div className={styles.buttons}>
              <PrimaryButton text='Generate' onClick={this.generateShortLink} />
              <DefaultButton text='Clear' className={styles.defaultButton} onClick={()=> 
              this.setState({ longUrl:'', shortenUrl: '', qrCode: null, selectedColor: '000000',
              selectedLogoGUID: blackGUID })} 
              />
            </div>
          </div>
          <VerticalDivider />
          <div className={styles.result}>
            <div style={{ display:'flex' }}>
              <Label>Shorten URL:</Label>
              <Label className={styles.shortUrl}>{this.state.shortenUrl}</Label>
            </div>            
            <div>
            <Label>QR Code:</Label>
            <Image src={this.state.qrCode} style={{ height:'200px' }} />
            </div>
          </div>
        </div>               
      </section>
    );
  }

  private generateShortLink = async() => {   
       
    // var payload = {
    //   long_url: this.state.longUrl,
    //   domain: 'link.fidelity.com',
    //   group_guid: this.state.selectedGuid,
    //   title: "Shirish" //this.props.ctx.pageContext.user.displayName,
    // } 
    // let shortenLinkResponse = await bitly.bitlyRequest('shorten', payload);
    // console.log(shortenLinkResponse);

    // generate Short Link  
    var shortLinkRequest = {
      "long_url": this.state.longUrl,
      "domain": 'link.fidelity.com',
      "group_guid": this.state.selectedGuid,
      "title": "Shirish" //this.props.ctx.pageContext.user.displayName,
    } 

    let headers:IHttpClientOptions = {
      method: 'POST',
      headers:{
        'Authorization': 'Bearer '+ userToken +'',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(shortLinkRequest)        
    } 
    this.props.httpClient.fetch('https://api-ssl.bitly.com/v4/bitlinks', HttpClient.configurations.v1, headers ).then((response: HttpClientResponse) => {  
        return response.json();  
      })  
      .then(shortenLinkResponse => {  
        console.log(shortenLinkResponse);  
        this.setState({
          shortenUrl: shortenLinkResponse.link // store the short link in state
        },()=>{ // trigger QR code generation call [ QR code generation can be triggered only after short link is generated ]
          let link = this.state.shortenUrl.replace(/(^\w+:|^)\/\//, '');
          
          let qrRequest = {
            color: this._colorCode, //this.state.selectedColor,
            exclude_bitly_logo: true,
            image_format: "png",         
            logo_image_guid: this.state.selectedLogoGUID,
            title: "Shirish" //this.props.ctx.pageContext.user.displayName,                     
          }
    
          let headers:IHttpClientOptions = {
            method: 'POST',
            headers:{
              'Authorization': 'Bearer '+ userToken +'',
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(qrRequest)        
          }     
          this.props.httpClient.fetch('https://api-ssl.bitly.com/v4/bitlinks/'+ link +'/qr', HttpClient.configurations.v1, headers ).then((response: HttpClientResponse) => {  
            return response.json();  
          })  
          .then(jsonResponse => {  
            console.log(jsonResponse);  
            this.setState({
              qrCode: jsonResponse.qr_code
            })
            
          });     
        })        
      });    
  }

  private updateGrCode = () => {
    let link = this.state.shortenUrl.replace(/(^\w+:|^)\/\//, '');
      
      let qrRequest = {
        color: this._colorCode, //this.state.selectedColor,
        exclude_bitly_logo: true,
        image_format: "png",         
        logo_image_guid: this.state.selectedLogoGUID                     
      }

      let headers:IHttpClientOptions = {
        method: 'PATCH',
        headers:{
          'Authorization': 'Bearer '+ userToken +'',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(qrRequest)        
      }     
      this.props.httpClient.fetch('https://api-ssl.bitly.com/v4/bitlinks/'+ link +'/qr', HttpClient.configurations.v1, headers ).then((response: HttpClientResponse) => {  
        return response.json();  
      })  
      .then(jsonResponse => {  
        console.log(jsonResponse);  
        this.setState({
          qrCode: jsonResponse.qr_code
        })
        
      });
  }

  private retrive = () => {
    let headers:IHttpClientOptions = {
      method: 'GET',
      headers:{
        'Authorization': 'Bearer '+ userToken +''        
      }              
    }     
    this.props.httpClient.fetch('https://api-ssl.bitly.com/v4/bitlinks/link.fidelity.com/3O9TPHU/qr?image_format=svg', HttpClient.configurations.v1, headers ).then((response: HttpClientResponse) => {  
      return response.json();  
    })  
    .then(jsonResponse => {  
      console.log(jsonResponse);  
      this.setState({
        qrCode: jsonResponse.qr_code
      })
      
    })
  }
}
