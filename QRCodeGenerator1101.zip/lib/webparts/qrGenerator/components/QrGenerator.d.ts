import * as React from 'react';
import { IQrGeneratorProps } from './IQrGeneratorProps';
export interface IQrGeneratorState {
    longUrl: string;
    shortenUrl: string;
    selectedGuid: string | number;
    qrCode: any;
    selectedColor: string | number;
    selectedLogoGUID: any;
    showError: boolean;
    errorMessage: string;
}
export default class QrGenerator extends React.Component<IQrGeneratorProps, IQrGeneratorState> {
    private _colorCode;
    private bitlyService;
    constructor(props: IQrGeneratorProps, state: IQrGeneratorState);
    render(): React.ReactElement<IQrGeneratorProps>;
    private validateInputs;
    private generateShortLink;
    private updateGrCode;
    private retriveQRCode;
}
//# sourceMappingURL=QrGenerator.d.ts.map