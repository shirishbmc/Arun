import { HttpClient } from '@microsoft/sp-http';

export interface IQrGeneratorProps {
  title: string;
  httpClient: HttpClient;
}
