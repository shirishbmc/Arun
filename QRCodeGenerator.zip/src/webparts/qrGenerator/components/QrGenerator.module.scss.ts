/* tslint:disable */
require("./QrGenerator.module.css");
const styles = {
  qrGenerator: 'qrGenerator_29631827',
  teams: 'teams_29631827',
  welcome: 'welcome_29631827',
  container: 'container_29631827',
  controls: 'controls_29631827',
  result: 'result_29631827',
  title: 'title_29631827',
  shortUrl: 'shortUrl_29631827',
  buttons: 'buttons_29631827',
  defaultButton: 'defaultButton_29631827',
  links: 'links_29631827'
};

export default styles;
/* tslint:enable */